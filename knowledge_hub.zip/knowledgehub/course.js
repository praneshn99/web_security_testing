function opt(){
    alert('Thank you for opting the course!')
}


