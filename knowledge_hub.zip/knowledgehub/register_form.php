<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "studyportal";
$errors = array();

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$original = $_SESSION['cap_code'];

if(isset($_GET['submit'])){
	$name = $_GET['fname'];
    $dob =   $_GET['datobth'];
    $gender = stripcslashes(stripslashes(htmlspecialchars(strip_tags($_GET['gender']))));
    $home = $_GET['address'];
    $contact = $_GET['mobile'];
    $email = $_GET['email'];
    $username = stripcslashes(stripslashes(htmlspecialchars(strip_tags($_GET['user']))));
    $password = stripcslashes(stripslashes(htmlspecialchars(strip_tags($_GET['password']))));
    $code = $_GET['captcha'];
	if($original === $code){
	$ins = "INSERT INTO register(name,dob,gender,address,contact,email,username,password) VALUES('$name','$dob','$gender','$home','$contact','$email','$username','$password')";
	if (mysqli_query($conn, $ins)) {
    header("location:login.html");
} else {
    echo "Error: " . $ins . "<br>" . mysqli_error($conn);
}
    }
    else{
        echo "Incorrect Captcha!<br/><a href=dummy.html>Click here</a> to go back.";
    } 
}
?> 